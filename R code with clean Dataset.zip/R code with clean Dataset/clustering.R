install.packages('pivottabler')
library(pivottabler)
library(tidyverse) # data wrangling
library(cluster) # clustering
library(factoextra) # clustering & cluster visualisation
library(gridExtra) # for plotting multiple visualisations in a grid


setwd("C:/Users/tible/OneDrive/Desktop/Clean Datasets")
alldata<-read.csv("AllDataNew.csv")
head(alldata)
alldata <- alldata[,-c(1)]
head(alldata)


 
#as.double(alldata.new[2])
kc <- kmeans(alldata, centers = 2, nstart = 25)
kc <- kmeans(alldata, 3)
#k4 <- kmeans(alldata, centers = 2, nstart = 25)


alldata <- data.frame(alldata, kc$cluster)
clusplot(alldata, kc$cluster, color=TRUE, shade=F, labels=0, lines=0, main='k-Means Cluster Analysis')

